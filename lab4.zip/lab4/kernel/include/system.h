void set(long addr, unsigned int value);
void reset(int tick);
