void cmd(char *s1);
void shell();
void reset(int tick);